# isomorphic pug example

This example shows how to use a different template engine (in this case pug)
to load the `time.pug` template on the backend and frontend.
