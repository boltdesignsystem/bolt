# zero-config example

in this example only the default configuration is used