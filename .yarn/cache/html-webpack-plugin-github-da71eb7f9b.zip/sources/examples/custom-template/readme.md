# custom template

This example uses a custom underscore template which inlines an partial using the html-loader:
`<%= require('html-loader!./partial.html') %>`
