var h1 = document.createElement('h1');
h1.innerHTML = 'c!';
document.body.appendChild(h1);
