'use strict';
module.exports = 'async';
