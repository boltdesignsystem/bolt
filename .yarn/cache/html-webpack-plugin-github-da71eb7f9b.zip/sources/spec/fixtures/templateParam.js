module.exports = function (templateParams) {
  return 'templateParams keys: "' + Object.keys(templateParams).join(',') + '"';
};
