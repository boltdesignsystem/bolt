'use strict';

require('./main.css');
require('./index.js');
