Component in progress

###### Install via NPM

```
npm install @bolt/components-page-footer
```

## Content

Set `content` as arbitrary HTML:

```
{% set content %}
  <p>Whatever HTML content you want</p>
{% endset %}
```
